var config = {};

config.email = {};
config.db = {};

config.email.username = 'wordup@nickturner.io';
config.email.password = 'THhGttG6p';
config.email.host = 'nlss2.a2hosting.com'
config.email.port = 465;
config.db.username = 'nick';
config.db.password = 'THhGttG6p';

module.exports = config;
